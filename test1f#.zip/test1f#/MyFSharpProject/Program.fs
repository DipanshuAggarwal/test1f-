﻿printfn"Part 1:"
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]
let highIncomeSalaries = salaries |> List.filter (fun salary -> salary > 100000)
printfn "High-income salaries: %A" highIncomeSalaries

let calculateTax salary =
    match salary with
    | s when s <= 49020 -> float s * 0.15
    | s when s <= 98040 -> float s * 0.205
    | s when s <= 151978 -> float s * 0.26
    | s when s <= 216511 -> float s * 0.29
    | _ -> float salary * 0.33

let taxes = salaries |> List.map calculateTax
printfn "Taxes for each salary: %A" taxes

let adjustedSalaries = 
    salaries 
    |> List.map (fun salary -> if salary < 49020 then salary + 20000 else salary)
printfn "Adjusted salaries (adding $20k to those under $49,020): %A" adjustedSalaries

let midRangeSalaries = salaries |> List.filter (fun salary -> salary >= 50000 && salary <= 100000)
let sumMidRangeSalaries = midRangeSalaries |> List.fold (+) 0
printfn "Sum of salaries between $50,000 and $100,000: %d" sumMidRangeSalaries

printfn "Part 2:"
let rec sumMultiplesOfThree n acc =
    if n < 3 then acc 
    else sumMultiplesOfThree (n - 3) (acc + n)

let result = sumMultiplesOfThree 27 0
printfn "Sum of multiples of 3 up to 27: %d" result

